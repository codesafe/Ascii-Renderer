# MySoftRenderer
A software rasterizer with Blinn-Phong Shading

[![4y8LVg.gif](https://z3.ax1x.com/2021/09/26/4y8LVg.gif)](https://imgtu.com/i/4y8LVg)
