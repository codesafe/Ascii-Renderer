#pragma once
#include <iostream> //to debug
typedef unsigned int uint32;
using namespace std;