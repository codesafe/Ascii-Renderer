#include "renderer.h"

CRenderer :: CRenderer()
{
	_MatrixIdentity(&m_Transform.world);
	_MatrixIdentity(&m_Transform.view);
	_MatrixIdentity(&m_Transform.proj);
	_MatrixIdentity(&m_Transform.vp);
	_MatrixIdentity(&m_Transform.tm);

	m_Viewport.nz = 0.0f;
	m_Viewport.fz = 1.0f;

	m_pTexture = NULL;

	SetLight(NULL);
}


CRenderer :: ~CRenderer()
{
	if (m_temp_vtx)
	{
		delete [] m_temp_vtx;
		m_temp_vtxn = 0;
		m_temp_vtx = 0;
	}
}


bool CRenderer :: Create(int w, int h)
{
	if (m_Raster.Create(w, h) == true)
	{
		SetViewport(0, 0, w, h);
		return true;
	}

	return false;
}

void CRenderer :: SetViewport(int x, int y, int w, int h)
{
	m_Viewport.x = x;
	m_Viewport.y = y;
	m_Viewport.w = w;
	m_Viewport.h = h;

	_MatrixIdentity(&m_Transform.vp);
	m_Transform.vp._11 = w * 0.5f;
	m_Transform.vp._41 = x + w * 0.5f;
	m_Transform.vp._22 = - h * 0.5f;
	m_Transform.vp._42 = y + h * 0.5f;
}

void CRenderer :: SetLight(const _LIGHT * light)
{
	if (light == NULL)
		m_Light.ambient = m_Light.diffuse = 0x000000;
	else
		m_Light = *light;
}

void CRenderer :: SetTexture(_TEXTURE * t)
{
	m_pTexture = t;
}

void CRenderer :: Clear(unsigned long color)
{
	m_Raster.FillColor(m_Viewport.x, m_Viewport.y, m_Viewport.w, m_Viewport.h, color);
	m_Raster.FillDepthBuffer(m_Viewport.x, m_Viewport.y, m_Viewport.w, m_Viewport.h, 1.0f);
}

void CRenderer :: DrawPrimitive(_PRIMITIVE p, const _VERTEX *v, int pn)
{
	const _VTX * vtx;
	int i;

	switch(p)
	{
	case _TRIANGLELIST :
		vtx = Transform(v, pn*3);
		for(i=0; i<pn; i++)
			DrawTriangle(&vtx[i*3], &vtx[i*3+1], &vtx[i*3+2]);
		break;	
	case _TRIANGLESTRIP :
		vtx = Transform(v, pn+1);
		for(i=0; i<pn; i++)
		{
			if ((i&1) == 0)
				DrawTriangle(&vtx[i], &vtx[i+1], &vtx[i+2]);
			else
				DrawTriangle(&vtx[i+2], &vtx[i+1], &vtx[i+0]);
		}
		break;	
	case _TRIANGLEFAN :
		vtx = Transform(v, pn+2);
		for(i=0; i<pn; i++)
			DrawTriangle(&vtx[0], &vtx[i+1], &vtx[i+2]);
		break;	
	}
}

void CRenderer :: DrawIndexedPrimitive(const _VERTEX *v, int vn, unsigned short *f, int fn)
{
	const _VTX * vtx;
	int i;

	vtx = Transform(v, vn);

	for(i=0; i<fn; i++)
		DrawTriangle(&vtx[f[i*3]], &vtx[f[i*3+1]], &vtx[f[i*3+2]]);
}

void CRenderer :: SetTransform(_TMSTATETYPE state, const _MATRIX & mat)
{
	switch(state)
	{
	case _VIEW :
		m_Transform.view = mat;
		break;
	case _PROJECTION :
		m_Transform.proj = mat;
		break;
	case _WORLD :
		m_Transform.world = mat;
		break;
	}

	_MATRIX temp[2];

	_MatrixMultiply(&temp[0], m_Transform.world, m_Transform.view);
	_MatrixMultiply(&temp[1], temp[0], m_Transform.proj);
	_MatrixMultiply(&m_Transform.tm, temp[1], m_Transform.vp);
}


//#define _USE_LIGHTTM

const CRenderer::_VTX * CRenderer :: Transform(const _VERTEX *v, int vn)
{
	static _VTX * vout = AllocVTX(vn);;
	int i;
#ifdef _USE_LIGHTTM
	_VECTOR	lv;

	if (m_Light.ambient != 0 || m_Light.diffuse != 0)
	{
		lv.x = m_Light.dir.x * m_Transform.world._11 + m_Light.dir.y * m_Transform.world._12 + m_Light.dir.z * m_Transform.world._13;
		lv.y = m_Light.dir.x * m_Transform.world._21 + m_Light.dir.y * m_Transform.world._22 + m_Light.dir.z * m_Transform.world._23;
		lv.z = m_Light.dir.x * m_Transform.world._31 + m_Light.dir.y * m_Transform.world._32 + m_Light.dir.z * m_Transform.world._33;
	}
#endif

	for(i=0; i<vn; i++)
	{
		float x, y, z, w, rhw;

		x = v[i].v.x * m_Transform.tm._11 + v[i].v.y * m_Transform.tm._21 + v[i].v.z * m_Transform.tm._31 + m_Transform.tm._41;
		y = v[i].v.x * m_Transform.tm._12 + v[i].v.y * m_Transform.tm._22 + v[i].v.z * m_Transform.tm._32 + m_Transform.tm._42;
		z = v[i].v.x * m_Transform.tm._13 + v[i].v.y * m_Transform.tm._23 + v[i].v.z * m_Transform.tm._33 + m_Transform.tm._43;
		w = v[i].v.x * m_Transform.tm._14 + v[i].v.y * m_Transform.tm._24 + v[i].v.z * m_Transform.tm._34 + m_Transform.tm._44;

		rhw = 1.0f / w;

		vout[i].x = x * rhw;
		vout[i].y = y * rhw;
		vout[i].z = z * rhw;
		vout[i].rhw = rhw;

		vout[i].tu = v[i].tu;
		vout[i].tv = v[i].tv;

		if (m_Light.ambient != 0 || m_Light.diffuse != 0)
		{
			int r, g, b;
			float t;

#ifndef _USE_LIGHTTM
			x = v[i].norm.x * m_Transform.world._11 + v[i].norm.y * m_Transform.world._21 + v[i].norm.z * m_Transform.world._31;
			y = v[i].norm.x * m_Transform.world._12 + v[i].norm.y * m_Transform.world._22 + v[i].norm.z * m_Transform.world._32;
			z = v[i].norm.x * m_Transform.world._13 + v[i].norm.y * m_Transform.world._23 + v[i].norm.z * m_Transform.world._33;
			t = x * m_Light.dir.x + y * m_Light.dir.y + z * m_Light.dir.z;
#else
			t = v[i].norm.x * lv.x + v[i].norm.y * lv.y + v[i].norm.z * lv.z;
#endif

			if (t <= 0.0f)
				t = 0.0f;

			r = _UNPACK_R(m_Light.ambient) + (int)(_UNPACK_R(m_Light.diffuse) * t);
			g = _UNPACK_G(m_Light.ambient) + (int)(_UNPACK_G(m_Light.diffuse) * t);
			b = _UNPACK_B(m_Light.ambient) + (int)(_UNPACK_B(m_Light.diffuse) * t);

			if (r > 255) r = 255;
			if (g > 255) g = 255;
			if (b > 255) b = 255;

			r = r * _UNPACK_R(v[i].diffuse) / 255;
			g = g * _UNPACK_G(v[i].diffuse) / 255;
			b = b * _UNPACK_B(v[i].diffuse) / 255;

			vout[i].color = _PACK(r, g, b, _UNPACK_B(v[i].diffuse));
		}	else
			vout[i].color = v[i].diffuse;

		vout[i].clipcode = CalcClipcode(vout[i].x, vout[i].y, vout[i].z);
	}

	return vout;
}

unsigned char CRenderer :: CalcClipcode(float x, float y, float z)
{
	unsigned char ccode = 0;

	if (z < m_Viewport.nz)
		ccode |= _C_NEAR;
	else
	if (z > m_Viewport.fz)
		ccode |= _C_FAR;

	if (x < m_Viewport.x)
		ccode |= _C_LEFT;
	else
	if (x >= m_Viewport.x + m_Viewport.w - 1)
		ccode |= _C_RIGHT;

	if (y < m_Viewport.y)
		ccode |= _C_TOP;
	else
	if (y >= m_Viewport.y + m_Viewport.h - 1)
		ccode |= _C_BOTTOM;

	return ccode;
}

bool CRenderer :: ISCCW(const _VTX *v1, const _VTX *v2, const _VTX *v3)
{
	return (v2->x-v1->x)*(v3->y-v1->y) - (v2->y-v1->y)*(v3->x-v1->x) < 0.0f ? true : false;
}

void CRenderer :: LerpVTX(_VTX * vout, const _VTX * v1, const _VTX *v2, unsigned char clipbit)
{
	float t = 1.0f;

	switch(clipbit)
	{
		case _C_NEAR : 
			t = (m_Viewport.nz - v1->z) / (v2->z - v1->z);
			break;
		case _C_FAR : 
			t = (m_Viewport.fz - v1->z) / (v2->z - v1->z);
			break;
		case _C_LEFT : 
			t = (m_Viewport.x - v1->x) / (v2->x - v1->x);
			break;
		case _C_RIGHT : 
			t = ((m_Viewport.x + m_Viewport.w - 1) - v1->x) / (v2->x - v1->x);
			break;
		case _C_TOP : 
			t = (m_Viewport.y - v1->y) / (v2->y - v1->y);
			break;
		case _C_BOTTOM :
			t = ((m_Viewport.y + m_Viewport.h - 1) - v1->y) / (v2->y - v1->y);
			break;
	}

	vout->x = Lerp(v1->x, v2->x, t);
	vout->y = Lerp(v1->y, v2->y, t);
	vout->z = Lerp(v1->z, v2->z, t);
	vout->rhw = Lerp(v1->rhw, v2->rhw, t);
	vout->color = LerpColor(v1->color, v2->color, t);
	vout->tu = Lerp(v1->tu, v2->tu, t);
	vout->tv = Lerp(v1->tv, v2->tv, t);
	vout->clipcode = CalcClipcode(vout->x, vout->y, vout->z);
}

void CRenderer :: DrawTriangle(const _VTX *v1, const _VTX *v2, const _VTX *v3, _CULL cull)
{
	if (cull != _NONE)
	{
		if (cull == _CCW && ISCCW(v1, v2, v3) == false)
			return ;
		if (cull == _CW && ISCCW(v1, v2, v3) == true)
			return ;
	}

	ClipAndDrawTriangle(v1, v2, v3, v1->clipcode | v2->clipcode | v3->clipcode);
}

void CRenderer :: ClipAndDrawTriangle(const _VTX *v1, const _VTX *v2, const _VTX *v3, unsigned char mask)
{
	int i, flags, n=0;
	_VTX v[6];

	if (mask == 0)
	{
		if (m_pTexture)
		{
			m_Raster.DrawTriangle(
				v1->x, v1->y, v1->z, v1->rhw, v1->tu, v1->tv, v1->color,
				v2->x, v2->y, v2->z, v2->rhw, v2->tu, v2->tv, v2->color,
				v3->x, v3->y, v3->z, v3->rhw, v3->tu, v3->tv, v3->color, m_pTexture);
		}	else
		{
			m_Raster.DrawTriangle(v1->x, v1->y, v1->z, v1->color,
				v2->x, v2->y, v2->z, v2->color,
				v3->x, v3->y, v3->z, v3->color);
		}
	}	else
	{
		for(flags=1; flags<(1<<6); flags<<=1)
		{
			if (mask&flags)
			{
				if ((v3->clipcode^v1->clipcode)&flags)
					LerpVTX(&v[n++], v3, v1, flags);
				if (!(v1->clipcode&flags))
					v[n++] = *v1;

				if ((v1->clipcode^v2->clipcode)&flags)
					LerpVTX(&v[n++], v1, v2, flags);
				if (!(v2->clipcode&flags))
					v[n++] = *v2;

				if ((v2->clipcode^v3->clipcode)&flags)
					LerpVTX(&v[n++], v2, v3, flags);
				if (!(v3->clipcode&flags))
					v[n++] = *v3;

				for(i=2; i<n; i++)
					ClipAndDrawTriangle(&v[0], &v[i-1], &v[i], mask^flags);

				return ;
			}
		}
	}
}

void CRenderer :: Paint(HDC hdc)
{
	m_Raster.Paint(hdc);
}


CRenderer::_VTX * CRenderer::m_temp_vtx = NULL;
int CRenderer::m_temp_vtxn = 0;


CRenderer::_VTX * CRenderer :: AllocVTX(int vn)
{
	if (m_temp_vtxn < vn)
	{
		if (m_temp_vtx)
			delete m_temp_vtx;
		m_temp_vtx = new _VTX [vn];
		m_temp_vtxn = vn;
	}
	return m_temp_vtx;
}