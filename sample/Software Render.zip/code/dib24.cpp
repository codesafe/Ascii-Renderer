#include <string.h>
#include "dib24.h"

CDIB24 :: CDIB24()
{
	m_pFramePtr = NULL;

	memset(&m_bmiHeader, 0, sizeof(m_bmiHeader));

	m_bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	m_bmiHeader.biPlanes = 1;
	m_bmiHeader.biBitCount = 24;
	m_bmiHeader.biCompression = BI_RGB;
}

void CDIB24::Release()
{
	if (m_pFramePtr)
	{
		delete [] m_pFramePtr;
		m_pFramePtr = NULL;
	}
}

bool CDIB24::Create(int w, int h)
{
	Release();

	m_iPitch = (w * 3 + 3) & (~3);
	m_pFramePtr = new unsigned char [m_iPitch * h];

	m_bmiHeader.biWidth = w;
	m_bmiHeader.biHeight = h;
	return true;
}

void CDIB24 :: Paint(HDC hdc)
{
	int w, h;
	w = m_bmiHeader.biWidth;
	h = m_bmiHeader.biHeight;
	SetDIBitsToDevice(hdc, 0, 0, w, h, 0, 0, 0, h, m_pFramePtr, (BITMAPINFO*)&m_bmiHeader, DIB_RGB_COLORS);
}