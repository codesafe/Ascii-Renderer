#ifndef _DIB24_
#define _DIB24_

#include <windows.h>
#include <string.h>

class CDIB24
{
public :
	CDIB24();
	~CDIB24() { Release(); }

	bool Create(int w, int h);
	void Paint(HDC hdc);

	unsigned char * GetPtr(int h) const { return m_pFramePtr + (m_bmiHeader.biHeight-1-h) * m_iPitch; }

	void PutPixel(int x, int y, unsigned long color) { memcpy(GetPtr(y) + x*3, &color, 3); }
	unsigned long GetPixel(int x, int y) const { unsigned long c=0; memcpy(&c, GetPtr(y) + x*3, 3); return c; }

private :
	void Release();

	BITMAPINFOHEADER m_bmiHeader;
	unsigned char * m_pFramePtr;
	int m_iPitch;
} ;

#endif