#ifndef _MATRIX__
#define _MATRIX__

#define	_PI			3.141592f
#define _DEGREE		(3.141592f / 180.0f)

struct _VECTOR {
	float x, y, z;
} ;

#define _POINT _VECTOR

struct _MATRIX {
	float _11, _12, _13, _14;
	float _21, _22, _23, _24;
	float _31, _32, _33, _34;
	float _41, _42, _43, _44;
} ;

_MATRIX * _MatrixIdentity(_MATRIX * pOut);
_MATRIX * _MatrixTranslation(_MATRIX *pOut, float x, float y, float z);
_MATRIX * _MatrixRotationY(_MATRIX *pOut, float rad);
_MATRIX * _MatrixRotationX(_MATRIX *pOut, float rad);
_MATRIX * _MatrixScaling(_MATRIX *pOut, float sx, float sy, float sz);
_MATRIX * _MatrixLookAtLH(_MATRIX *pOut, const _VECTOR & eye, const _VECTOR & at, const _VECTOR & up);

_MATRIX * _MatrixMultiply(_MATRIX * pOut, const _MATRIX & m1, const _MATRIX & m2);
_MATRIX * _MatrixInverse(_MATRIX * pOut, const _MATRIX & m);
_VECTOR * _Transform(_VECTOR * pOut, const _VECTOR & v, const _MATRIX & m);
_VECTOR * _Normalize(_VECTOR * pOut, const _VECTOR & v);

_MATRIX * _MatrixPerspectiveFovLH(_MATRIX *pOut, float fovY, float Aspect, float zn, float zf);

#endif