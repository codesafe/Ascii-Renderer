#include <math.h>
#include "matrix.h"

_VECTOR * _Transform(_VECTOR * pOut, const _VECTOR & v, const _MATRIX & m)
{
	pOut->x = v.x * m._11 + v.y * m._21 + v.z * m._31 + m._41;
	pOut->y = v.x * m._12 + v.y * m._22 + v.z * m._32 + m._42;
	pOut->z = v.x * m._13 + v.y * m._23 + v.z * m._33 + m._43;
	return pOut;
}

_MATRIX * _MatrixIdentity(_MATRIX * pOut)
{
	pOut->_11 = 1.0f;
	pOut->_12 = 0.0f;
	pOut->_13 = 0.0f;
	pOut->_14 = 0.0f;

	pOut->_21 = 0.0f;
	pOut->_22 = 1.0f;
	pOut->_23 = 0.0f;
	pOut->_24 = 0.0f;

	pOut->_31 = 0.0f;
	pOut->_32 = 0.0f;
	pOut->_33 = 1.0f;
	pOut->_34 = 0.0f;

	pOut->_41 = 0.0f;
	pOut->_42 = 0.0f;
	pOut->_43 = 0.0f;
	pOut->_44 = 1.0f;

	return pOut;
}

_MATRIX * _MatrixScaling(_MATRIX *pOut, float sx, float sy, float sz)
{
	_MatrixIdentity(pOut);
	pOut->_11 = sx;
	pOut->_22 = sy;
	pOut->_33 = sz;
	return pOut;
}

_MATRIX * _MatrixTranslation(_MATRIX *pOut, float x, float y, float z)
{
	_MatrixIdentity(pOut);
	pOut->_41 = x;
	pOut->_42 = y;
	pOut->_43 = z;
	return pOut;
}

_MATRIX * _MatrixRotationY(_MATRIX *pOut, float rad)
{
	float cs = (float) cos(rad);
	float ss = (float) sin(rad);

	_MatrixIdentity(pOut);

	pOut->_11 = cs;
	pOut->_13 = -ss;
	pOut->_31 = ss;
	pOut->_33 = cs;
	return pOut;
}

_MATRIX * _MatrixRotationX(_MATRIX *pOut, float rad)
{
	float cs = (float) cos(rad);
	float ss = (float) sin(rad);

	_MatrixIdentity(pOut);

	pOut->_22 = cs;
	pOut->_23 = ss;
	pOut->_32 = -ss;
	pOut->_33 = cs;
	return pOut;
}

_MATRIX * _MatrixMultiply(_MATRIX * pOut, const _MATRIX & m1, const _MATRIX & m2)
{
	pOut->_11 = m1._11 * m2._11 + m1._12 * m2._21 + m1._13 * m2._31 + m1._14 * m2._41;
	pOut->_12 = m1._11 * m2._12 + m1._12 * m2._22 + m1._13 * m2._32 + m1._14 * m2._42;
	pOut->_13 = m1._11 * m2._13 + m1._12 * m2._23 + m1._13 * m2._33 + m1._14 * m2._43;
	pOut->_14 = m1._11 * m2._13 + m1._12 * m2._24 + m1._13 * m2._34 + m1._14 * m2._44;

	pOut->_21 = m1._21 * m2._11 + m1._22 * m2._21 + m1._23 * m2._31 + m1._24 * m2._41;
	pOut->_22 = m1._21 * m2._12 + m1._22 * m2._22 + m1._23 * m2._32 + m1._24 * m2._42;
	pOut->_23 = m1._21 * m2._13 + m1._22 * m2._23 + m1._23 * m2._33 + m1._24 * m2._43;
	pOut->_24 = m1._21 * m2._13 + m1._22 * m2._24 + m1._23 * m2._34 + m1._24 * m2._44;

	pOut->_31 = m1._31 * m2._11 + m1._32 * m2._21 + m1._33 * m2._31 + m1._34 * m2._41;
	pOut->_32 = m1._31 * m2._12 + m1._32 * m2._22 + m1._33 * m2._32 + m1._34 * m2._42;
	pOut->_33 = m1._31 * m2._13 + m1._32 * m2._23 + m1._33 * m2._33 + m1._34 * m2._43;
	pOut->_34 = m1._31 * m2._13 + m1._32 * m2._24 + m1._33 * m2._34 + m1._34 * m2._44;

	pOut->_41 = m1._41 * m2._11 + m1._42 * m2._21 + m1._43 * m2._31 + m1._44 * m2._41;
	pOut->_42 = m1._41 * m2._12 + m1._42 * m2._22 + m1._43 * m2._32 + m1._44 * m2._42;
	pOut->_43 = m1._41 * m2._13 + m1._42 * m2._23 + m1._43 * m2._33 + m1._44 * m2._43;
	pOut->_44 = m1._41 * m2._13 + m1._42 * m2._24 + m1._43 * m2._34 + m1._44 * m2._44;

	return pOut;
}

_MATRIX * _MatrixInverse(_MATRIX * pOut, const _MATRIX & m)
{
	float scale;

	scale = 1.0f / (m._11 * (m._22 * m._33 - m._23 * m._32) +
		m._12 * (m._23 * m._31 - m._21 * m._33) +
		m._13 * (m._21 * m._32 - m._22 * m._31));

	pOut->_11 = scale * (m._22 * m._33 - m._23 * m._32);
	pOut->_12 = scale * (m._13 * m._32 - m._12 * m._33);
	pOut->_13 = scale * (m._12 * m._23 - m._13 * m._22);

	pOut->_21 = scale * (m._23 * m._31 - m._21 * m._33);
	pOut->_22 = scale * (m._11 * m._33 - m._13 * m._31);
	pOut->_23 = scale * (m._13 * m._21 - m._11 * m._23);

	pOut->_31 = scale * (m._21 * m._32 - m._22 * m._31);
	pOut->_32 = scale * (m._12 * m._31 - m._11 * m._32);
	pOut->_33 = scale * (m._11 * m._22 - m._12 * m._21);

	pOut->_41 = - (m._41 * pOut->_11 + m._42 * pOut->_21 + m._43 * pOut->_31);
	pOut->_42 = - (m._41 * pOut->_12 + m._42 * pOut->_22 + m._43 * pOut->_32);
	pOut->_43 = - (m._41 * pOut->_13 + m._42 * pOut->_23 + m._43 * pOut->_33);

	return pOut;
}

_MATRIX * _MatrixPerspectiveFovLH(_MATRIX *pOut, float fovY, float aspect, float zn, float zf)
{
	float tanfov = (float) tan(fovY * 0.5f) ;

	pOut->_11 = (1.0f / tanfov) / aspect;
	pOut->_12 = 0.0f;
	pOut->_13 = 0.0f;
	pOut->_14 = 0.0f;

	pOut->_21 = 0.0f;
	pOut->_22 = (1.0f / tanfov);
	pOut->_23 = 0.0f;
	pOut->_24 = 0.0f;

	pOut->_31 = 0.0f;
	pOut->_32 = 0.0f;
	pOut->_33 = zf / (zf - zn);
	pOut->_34 = 1.0f;

	pOut->_41 = 0.0f;
	pOut->_42 = 0.0f;
	pOut->_43 = - zn * zf / (zf - zn);
	pOut->_44 = 0.0f;

	return pOut;
}

_VECTOR * _Normalize(_VECTOR * pOut, const _VECTOR & v)
{
	float mag = 1.0f / (float) sqrt(v.x*v.x + v.y*v.y + v.z*v.z);
	pOut->x = v.x * mag;
	pOut->y = v.y * mag;
	pOut->z = v.z * mag;
	return pOut;
}

//_MATRIX * _MatrixLookAtLH(_MATRIX *pOut, const _VECTOR & eye, const _VECTOR & at, const _VECTOR & up)
//{
//}
