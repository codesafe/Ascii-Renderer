#ifndef _RASTERIZER_
#define _RASTERIZER_

#include "dib24.h"

struct _TEXTURE
{
	int w, h, pitch;
	unsigned char * image;
} ;

class	CRasterizer
{
public :
	CRasterizer();
	~CRasterizer();

	bool Create(int w, int h);
	void Paint(HDC hdc) { m_DIB.Paint(hdc); }

	void FillColor(int x, int y, int w, int h, unsigned long color);
	void FillDepthBuffer(int x, int y, int w, int h, float depth);

	void DrawLine(float x1, float y1, unsigned long c1, float x2, float y2, unsigned long c2);

	void DrawTriangle(float x1, float y1, float z1, unsigned long c1,
					  float x2, float y2, float z2, unsigned long c2,
					  float x3, float y3, float z3, unsigned long c3);

	void DrawTriangle(float x1, float y1, float z1, float w1, float u1, float v1, unsigned long c1,
					  float x2, float y2, float z2, float w2, float u2, float v2, unsigned long c2,
					  float x3, float y3, float z3, float w3, float u3, float v3, unsigned long c3, _TEXTURE * texture);


private :
	struct _EDGE {
		float x, z, w;
		float r, g, b, a;
		float u, v;
	} ;
	void RasterLine(int y, _EDGE * l, _EDGE * r, _TEXTURE * tex);

	static unsigned long ReadTexel(_TEXTURE * t, float u, float v);
	static unsigned long ReadTexel(_TEXTURE * t, int x, int y);

	struct _DEPTHBUFFER
	{
		int w, h;
		float * pBuffer;
//		unsigned short * pBuffer;
	}	m_Zbuffer;

private :
	CDIB24	m_DIB;
} ;

#define _UNPACK_A(C) (int)(((C)>>24)&0xFF)
#define _UNPACK_R(C) (int)(((C)>>16)&0xFF)
#define _UNPACK_G(C) (int)(((C)>>8)&0xFF)
#define _UNPACK_B(C) (int)((C)&0xFF)
#define _PACK(R, G, B, A) (((A)<<24) | ((R)<<16) | ((G)<<8) | (B))

template <class _Tx>
float Lerp(_Tx v1, _Tx v2, float t) { return v1 + (v2 - v1) * t; }

unsigned long LerpColor(unsigned long c1, unsigned long c2, float t);

#endif