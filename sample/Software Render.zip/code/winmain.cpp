#include <windows.h>
#include "renderer.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

struct _MODEL 
{
	int vtxn;
	_VERTEX * vtx;
	int facen;
	unsigned short *face;
};

static CRenderer g_Renderer;
static float g_Aspect = 1.0f;
_TEXTURE * g_pTexture = NULL;
_MODEL * g_pModel = NULL;


_MODEL * LoadModel(const char *fname)
{
	FILE *fp = fopen(fname, "rt");
	_MODEL * model;
	int i;
	int face[3];
	if (fp == NULL)
		return NULL;
	model = new _MODEL;
	fscanf(fp, "%d", &model->vtxn);
	model->vtx = new _VERTEX [model->vtxn];
	for(i=0; i<model->vtxn; i++)
	{
		model->vtx[i].diffuse = 0xFFFFFFFF;

		fscanf(fp, "%f %f %f %f %f %f %f %f",
			&model->vtx[i].v.x, &model->vtx[i].v.y, &model->vtx[i].v.z,
			&model->vtx[i].tu, &model->vtx[i].tv,
			&model->vtx[i].norm.x, &model->vtx[i].norm.y, &model->vtx[i].norm.z);
	}
	fscanf(fp, "%d", &model->facen);
	model->face = new unsigned short [model->facen*3];
	for(i=0; i<model->facen*3; i+=3)
	{
		fscanf(fp, "%d %d %d", &face[0], &face[1], &face[2]);
		model->face[i+0] = face[0];
		model->face[i+1] = face[1];
		model->face[i+2] = face[2];
	}
	fclose(fp);
	return model;
}

_TEXTURE * LoadTexture(const char *fname)
{
	FILE *fp = fopen(fname, "rb");
	_TEXTURE *pTexture;
	BITMAPINFOHEADER bm;
	int i, off;
	if (fp == NULL)
		return NULL;
	fseek(fp, 10, SEEK_SET);

	fread(&off, 4, 1, fp);
	fread(&bm, 1, sizeof(bm), fp);
	fseek(fp, off, SEEK_SET);
	if (bm.biBitCount != 24)
		return NULL;
	pTexture = new _TEXTURE;
	pTexture->w = bm.biWidth;
	pTexture->h = bm.biHeight;
	pTexture->pitch = bm.biWidth * 3;
	pTexture->image = new unsigned char [pTexture->h * pTexture->pitch];
	for(i=bm.biHeight-1; i>=0; i--)
	{
		fread(pTexture->image + i*pTexture->pitch, 1, pTexture->pitch, fp);
		fseek(fp, (4 - ((bm.biWidth*3)&3)) & 3, SEEK_CUR); // skip padding bytes
	}
	fclose(fp);
	return pTexture;
}

#include <stdio.h>

void Init()
{
	g_pModel = LoadModel("street01.txt");
	g_pTexture = LoadTexture("street01.bmp");
}
void Unint()
{
	if (g_pModel)
	{
		delete [] g_pModel->face;
		delete [] g_pModel->vtx;
		delete g_pModel;
		g_pModel = NULL;
	}
	if (g_pTexture)
	{
		delete [] g_pTexture->image;
		delete g_pTexture;
		g_pTexture = NULL;
	}
}

bool Resize(int w, int h)
{
	g_Aspect = (float) w / h;
	return g_Renderer.Create(w, h);
}

#include <math.h>

void RenderScene(HDC hdc)
{
	_LIGHT light;
	light.ambient = 0xF00FF;
	light.diffuse = 0xFF0000;
	light.dir.x = 0.0f;
	light.dir.y = 0.0f;
	light.dir.z = -1.0f;

	g_Renderer.Clear(0x000000);
	g_Renderer.SetLight(&light);

	_MATRIX m;

	_MatrixPerspectiveFovLH(&m, 45.0f * _DEGREE, g_Aspect, 1.0f, 400.0f);
	g_Renderer.SetTransform(CRenderer::_PROJECTION, m);

	float rad = timeGetTime()*0.0001f;

	_MATRIX tm[4];

	_MatrixRotationY(&tm[0], rad);
	_MatrixRotationX(&tm[1], -3.141592f * 0.25f);
	_MatrixTranslation(&tm[2], 0, 0.0f, 150.0f);
	_MatrixMultiply(&tm[3], tm[0], tm[1]);
	_MatrixMultiply(&m, tm[3], tm[2]);

	g_Renderer.SetTransform(CRenderer::_WORLD, m);

	g_Renderer.SetTexture(g_pTexture);
	g_Renderer.DrawIndexedPrimitive(g_pModel->vtx, g_pModel->vtxn, g_pModel->face, g_pModel->facen);

	g_Renderer.Paint(hdc);
}

LRESULT CALLBACK WinProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_SIZE :
			Resize(LOWORD(lParam), HIWORD(lParam));
			break;
		case WM_PAINT: {
			PAINTSTRUCT ps;
			HDC hdc;
			hdc = BeginPaint(hWnd, &ps);
			RenderScene(hdc);
			EndPaint(hWnd, &ps);
			break;
		}
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}



int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	HWND hWnd;
	WNDCLASS wcl;
	MSG msg;

	wcl.style = 0;
	wcl.lpfnWndProc = WinProc;
	wcl.cbClsExtra = 0;
	wcl.cbWndExtra = 0;
	wcl.hInstance = hInstance;
	wcl.hIcon = LoadIcon(NULL, (LPCTSTR)IDI_APPLICATION);
	wcl.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcl.hbrBackground = (HBRUSH) GetStockObject(BLACK_BRUSH);
	wcl.lpszMenuName = NULL;
	wcl.lpszClassName = "_0error";

	if (!RegisterClass(&wcl))
		return NULL;

	Init();

	hWnd = CreateWindow(wcl.lpszClassName, "renderer",
						WS_OVERLAPPEDWINDOW|WS_VISIBLE,
						CW_USEDEFAULT, CW_USEDEFAULT,
						320, 240,
						NULL, NULL, hInstance, NULL);

	do {
		if (PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE) == 0)
		{
			InvalidateRect(hWnd, NULL, FALSE);
			UpdateWindow(hWnd);
		}	else
		if (GetMessage(&msg, NULL, 0, 0)) {
			TranslateMessage (&msg) ;
			DispatchMessage (&msg) ;
		}	else
			break;
	}	while(1);

	Unint();

	return msg.wParam;
}
