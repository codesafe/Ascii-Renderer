#ifndef _RENdERER_
#define _RENdERER_

#include "rasterizer.h"
#include "matrix.h"

struct _VERTEX {
	_VECTOR	v;
	_VECTOR	norm;
	unsigned long diffuse;
	float tu, tv;
} ;

struct _LIGHT {
	_VECTOR dir;
	unsigned long ambient;
	unsigned long diffuse;
} ;

class	CRenderer
{
public :
	CRenderer();
	~CRenderer();

	bool Create(int w, int h);

	void Clear(unsigned long color);
	void Paint(HDC hdc);

	void SetViewport(int x, int y, int w, int h);

	void SetLight(const _LIGHT * light);
	void SetTexture(_TEXTURE * t);

	enum _TMSTATETYPE {
		_VIEW,
		_PROJECTION,
		_WORLD,
	} ;
	void SetTransform(_TMSTATETYPE state, const _MATRIX & mat);

	enum _PRIMITIVE  {
		_TRIANGLELIST,
		_TRIANGLESTRIP,
		_TRIANGLEFAN
	};
	void DrawPrimitive(_PRIMITIVE p, const _VERTEX *v, int pn);
	void DrawIndexedPrimitive(const _VERTEX *v, int vn, unsigned short *f, int fn);

private :
	struct _VTX
	{
		float x, y, z, rhw;
		unsigned long color;
		float tu, tv;
		unsigned char clipcode;
	} ;

	const _VTX * Transform(const _VERTEX *v, int vn);

	enum _CULL {
		_CCW,
		_CW,
		_NONE,
	} ;

	void DrawTriangle(const _VTX *v1, const _VTX *v2, const _VTX *v3, _CULL cul=_CCW);

	bool ISCCW(const _VTX *v1, const _VTX *v2, const _VTX *v3); // for backface culling

	enum _CLIPBIT {
		_C_NEAR		= 0x01,
		_C_FAR		= 0x02,
		_C_LEFT		= 0x04,
		_C_RIGHT	= 0x08,
		_C_TOP		= 0x10,
		_C_BOTTOM	= 0x20,
	} ;
	unsigned char CalcClipcode(float x, float y, float z); // near, far, left, right, top, bottom
	void LerpVTX(_VTX * vout, const _VTX *v1, const _VTX *v2, unsigned char clipbit);
	void ClipAndDrawTriangle(const _VTX *v1, const _VTX *v2, const _VTX *v3, unsigned char mask);

private :
	CRasterizer	m_Raster;

private :
	struct _TM {
		_MATRIX	world, view, proj;
		_MATRIX tm;
		_MATRIX vp;
	}	m_Transform;

	struct _VIEWPORT {
		int x, y, w, h;
		float nz, fz;
	}	m_Viewport;

	_LIGHT m_Light;
	_TEXTURE * m_pTexture;

private :
	static _VTX * m_temp_vtx;
	static int m_temp_vtxn;
	static _VTX * AllocVTX(int vn);
} ;


#endif