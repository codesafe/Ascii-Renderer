#include "rasterizer.h"
#include <math.h>

//#define _WIREFRAME
#define _PERSPETIVE_CORRECT
#define _ALPHATEST	0

CRasterizer :: CRasterizer()
{
	m_Zbuffer.pBuffer = NULL;
}


CRasterizer :: ~CRasterizer()
{
	if (m_Zbuffer.pBuffer)
		delete [] m_Zbuffer.pBuffer;
}


bool CRasterizer :: Create(int w, int h)
{
	if (m_DIB.Create(w, h) == true)
	{
		if (m_Zbuffer.pBuffer)
			delete [] m_Zbuffer.pBuffer;
		m_Zbuffer.pBuffer = new float [w * h];
//		m_Zbuffer.pBuffer = new unsigned short [w * h];
		m_Zbuffer.w = w;
		m_Zbuffer.h = h;
		return true;
	}
	return false;
}


void CRasterizer :: FillColor(int x, int y, int w, int h, unsigned long color)
{
	unsigned char * ptr;
	int i, j;

	for(i=0; i<h; i++)
	{
		ptr = m_DIB.GetPtr(y + i) + x * 3;

		for(j=0; j<w; j++, ptr+=3)
			memcpy(ptr, &color, 3);
	}
}


void CRasterizer :: FillDepthBuffer(int x, int y, int w, int h, float depth)
{
	float * ptr;
//	unsigned short * ptr;
	int i, j;

	for(i=0; i<h; i++)
	{
		ptr = &m_Zbuffer.pBuffer[(y + i) * m_Zbuffer.w + x * 3];

		for(j=0; j<w; j++)
		{
			ptr[j] = depth;
//			ptr[j] = (int)(depth * 65535);
		}
	}
}


void CRasterizer :: DrawTriangle(float x1, float y1, float z1, unsigned long c1,
								 float x2, float y2, float z2, unsigned long c2,
								 float x3, float y3, float z3, unsigned long c3)
{
	if (y1 > y2)
		DrawTriangle(x2, y2, z2, c2, x1, y1, z1, c1, x3, y3, z3, c3);
	else
	if (y1 > y3)
		DrawTriangle(x3, y3, z3, c3, x1, y1, z1, c1, x2, y2, z2, c2);
	else
	if (y2 > y3)
		DrawTriangle(x1, y1, z1, c1, x3, y3, z3, c3, x2, y2, z2, c2);
	else
	{
		DrawTriangle(x1, y1, z1, 1, 0, 0, c1,
			x2, y2, z2, 1, 0, 0, c2,
			x3, y3, z2, 1, 0, 0, c3, NULL);
	}
}


void CRasterizer :: DrawTriangle(float x1, float y1, float z1, float w1, float u1, float v1, unsigned long c1,
								 float x2, float y2, float z2, float w2, float u2, float v2, unsigned long c2,
								 float x3, float y3, float z3, float w3, float u3, float v3, unsigned long c3, _TEXTURE * texture)
{
	if (y1 > y2) {
		DrawTriangle(x2, y2, z2, w2, u2, v2, c2,
					 x1, y1, z1, w1, u1, v1, c1,
					 x3, y3, z3, w3, u3, v3, c3, texture);
	}	else
	if (y1 > y3) {
		DrawTriangle(x3, y3, z3, w3, u3, v3, c3,
					 x1, y1, z1, w1, u1, v1, c1,
					 x2, y2, z2, w2, u2, v2, c2, texture);
	}	else
	if (y2 > y3) {
		DrawTriangle(x1, y1, z1, w1, u1, v1, c1,
					 x3, y3, z3, w3, u3, v3, c3,
					 x2, y2, z2, w2, u2, v2, c2, texture);
	}	else
	{
#ifdef _WIREFRAME
		DrawLine(x1, y1, c1, x2, y2, c2);
		DrawLine(x2, y2, c2, x3, y3, c3);
		DrawLine(x3, y3, c3, x1, y1, c1);
#else
		int y, iy1, iy2, iy3;
		_EDGE e[2];
		float t1, t2;

		iy1 = (int)(y1);
		iy2 = (int)(y2);
		iy3 = (int)(y3);

		for(y=iy1; y<iy2; y++)
		{
			t1 = (y - iy1 + 0.5f) / (iy2 - iy1);
			e[0].x = Lerp(x1, x2, t1);
			e[0].z = Lerp(z1, z2, t1);
			e[0].w = Lerp(w1, w2, t1);
#ifdef _PERSPETIVE_CORRECT
			e[0].u = Lerp(u1 * w1, u2 * w2, t1);
			e[0].v = Lerp(v1 * w1, v2 * w2, t1);
#else
			e[0].u = Lerp(u1, u2, t1);
			e[0].v = Lerp(v1, v2, t1);
#endif
			e[0].r = Lerp(_UNPACK_R(c1), _UNPACK_R(c2), t1);
			e[0].g = Lerp(_UNPACK_G(c1), _UNPACK_G(c2), t1);
			e[0].b = Lerp(_UNPACK_B(c1), _UNPACK_B(c2), t1);
			e[0].a = Lerp(_UNPACK_A(c1), _UNPACK_A(c2), t1);

			t2 = (y - iy1 + 0.5f) / (iy3 - iy1 + 1);
			e[1].x = Lerp(x1, x3, t2);
			e[1].z = Lerp(z1, z3, t2);
			e[1].w = Lerp(w1, w3, t2);
#ifdef _PERSPETIVE_CORRECT
			e[1].u = Lerp(u1 * w1, u3 * w3, t2);
			e[1].v = Lerp(v1 * w1, v3 * w3, t2);
#else
			e[1].u = Lerp(u1, u3, t2);
			e[1].v = Lerp(v1, v3, t2);
#endif
			e[1].r = Lerp(_UNPACK_R(c1), _UNPACK_R(c3), t2);
			e[1].g = Lerp(_UNPACK_G(c1), _UNPACK_G(c3), t2);
			e[1].b = Lerp(_UNPACK_B(c1), _UNPACK_B(c3), t2);
			e[1].a = Lerp(_UNPACK_A(c1), _UNPACK_A(c3), t2);

			RasterLine(y, &e[0], &e[1], texture);
		}

		for(; y<=iy3; y++)
		{
			t1 = (y - iy2 + 0.5f) / (iy3 - iy2 + 1);
			e[0].x = Lerp(x2, x3, t1);
			e[0].z = Lerp(z2, z3, t1);
			e[0].w = Lerp(w2, w3, t1);
#ifdef _PERSPETIVE_CORRECT
			e[0].u = Lerp(u2 * w2, u3 * w3, t1);
			e[0].v = Lerp(v2 * w2, v3 * w3, t1);
#else
			e[0].u = Lerp(u2, u3, t1);
			e[0].v = Lerp(v2, v3, t1);
#endif
			e[0].r = Lerp(_UNPACK_R(c2), _UNPACK_R(c3), t1);
			e[0].g = Lerp(_UNPACK_G(c2), _UNPACK_G(c3), t1);
			e[0].b = Lerp(_UNPACK_B(c2), _UNPACK_B(c3), t1);
			e[0].a = Lerp(_UNPACK_A(c2), _UNPACK_A(c3), t1);

			t2 = (y - iy1 + 0.5f) / (iy3 - iy1 + 1);
			e[1].x = Lerp(x1, x3, t2);
			e[1].z = Lerp(z1, z3, t2);
			e[1].w = Lerp(w1, w3, t2);
#ifdef _PERSPETIVE_CORRECT
			e[1].u = Lerp(u1 * w1, u3 * w3, t2);
			e[1].v = Lerp(v1 * w1, v3 * w3, t2);
#else
			e[1].u = Lerp(u1, u3, t2);
			e[1].v = Lerp(v1, v3, t2);
#endif
			e[1].r = Lerp(_UNPACK_R(c1), _UNPACK_R(c3), t2);
			e[1].g = Lerp(_UNPACK_G(c1), _UNPACK_G(c3), t2);
			e[1].b = Lerp(_UNPACK_B(c1), _UNPACK_B(c3), t2);
			e[1].a = Lerp(_UNPACK_A(c1), _UNPACK_A(c3), t2);

			RasterLine(y, &e[0], &e[1], texture);
		}
#endif
	}
}


//#define _BILINEAR_FILTERING

unsigned long CRasterizer :: ReadTexel(_TEXTURE * tex, int x, int y)
{
	unsigned long c = 0xFF000000;
	x %= tex->w;
	y %= tex->h;
	memcpy(&c, tex->image + y * tex->pitch + x * 3, 3);
	return c;
}


unsigned long CRasterizer :: ReadTexel(_TEXTURE * tex, float u, float v)
{
	int itu, itv;

	itu = (int)(u * tex->w);
	itv = (int)(v * tex->h);

#ifndef _BILINEAR_FILTERING
	return ReadTexel(tex, itu, itv);
#else
	float wu, wv, w[2][2], r, g, b;
	unsigned long c[2][2];

	wu = (float) fmod(u * tex->w, 1.0f);
	wv = (float) fmod(v * tex->h, 1.0f);

	w[0][0] = (1.0f - wu) * (1.0f - wv);
	w[0][1] = wu * (1.0f - wv);
	w[1][0] = (1.0f - wu) * wv;
	w[1][1] = wu * wv;

	c[0][0] = ReadTexel(tex, itu, itv);
	c[0][1] = ReadTexel(tex, itu + 1, itv);
	c[1][0] = ReadTexel(tex, itu, itv + 1);
	c[1][1] = ReadTexel(tex, itu + 1, itv + 1);

	r = _UNPACK_R(c[0][0]) * w[0][0] + _UNPACK_R(c[0][1]) * w[0][1] +
		_UNPACK_R(c[1][0]) * w[1][0] + _UNPACK_R(c[1][1]) * w[1][1];
	g = _UNPACK_G(c[0][0]) * w[0][0] + _UNPACK_G(c[0][1]) * w[0][1] +
		_UNPACK_G(c[1][0]) * w[1][0] + _UNPACK_G(c[1][1]) * w[1][1];
	b = _UNPACK_B(c[0][0]) * w[0][0] + _UNPACK_B(c[0][1]) * w[0][1] +
		_UNPACK_B(c[1][0]) * w[1][0] + _UNPACK_B(c[1][1]) * w[1][1];

	return _PACK((int)r, (int)g, (int)b, 0xFF);
#endif
}


void CRasterizer :: RasterLine(int y, _EDGE * l, _EDGE * r, _TEXTURE * tex)
{
	if (l->x > r->x)
		RasterLine(y, r, l, tex);
	else
	{
		int x, ix1, ix2;
		int rgb[4];
		float t;
		float z;
//		unsigned short z;

		ix1 = (int)(l->x);
		ix2 = (int)(r->x);

		for(x=ix1; x<=ix2; x++)
		{
			t = (x - ix1 + 0.5f) / (ix2 - ix1 + 1);

			z = Lerp(l->z, r->z, t);
//			z = (int)(Lerp(l->z, r->z, t) * 65535.0f);

			if (m_Zbuffer.pBuffer[y * m_Zbuffer.w + x] >= z)
			{
				m_Zbuffer.pBuffer[y * m_Zbuffer.w + x] = z;

				rgb[0] = (int)Lerp(l->r, r->r, t);
				rgb[1] = (int)Lerp(l->g, r->g, t);
				rgb[2] = (int)Lerp(l->b, r->b, t);
				rgb[3] = (int)Lerp(l->a, r->a, t);

				if (tex != NULL)
				{
					unsigned long texcolor;
					float tu, tv;

#ifdef _PERSPETIVE_CORRECT
					tu = Lerp(l->u, r->u, t) / Lerp(l->w, r->w, t);
					tv = Lerp(l->v, r->v, t) / Lerp(l->w, r->w, t);
#else
					tu = Lerp(l->u, r->u, t);
					tv = Lerp(l->v, r->v, t);
#endif
					texcolor = ReadTexel(tex, tu, tv);

					rgb[0] = rgb[0] * _UNPACK_R(texcolor) / 0xFF;
					rgb[1] = rgb[1] * _UNPACK_G(texcolor) / 0xFF;
					rgb[2] = rgb[2] * _UNPACK_B(texcolor) / 0xFF;
					rgb[3] = rgb[3] * _UNPACK_A(texcolor) / 0xFF;
				}

				if (rgb[3] > _ALPHATEST)
				{
					if (rgb[3] < 0xFF)
					{
						unsigned long framc = m_DIB.GetPixel(x, y);
						t = (float)rgb[3] / 0xFF;
						rgb[0] = (int) Lerp(rgb[0], _UNPACK_R(framc), t);
						rgb[1] = (int) Lerp(rgb[1], _UNPACK_G(framc), t);
						rgb[2] = (int) Lerp(rgb[2], _UNPACK_B(framc), t);
					}

					unsigned long c = _PACK(rgb[0], rgb[1], rgb[2], 0);

					m_DIB.PutPixel(x, y, c);
				}
			}
		}
	}
}


void CRasterizer :: DrawLine(float x1, float y1, unsigned long c1, float x2, float y2, unsigned long c2)
{
	if (y1 > y2)
		DrawLine(x2, y2, c2, x1, y1, c1);
	else
	{
		int x, y, iy1, iy2;
		unsigned long c;
		float t;

		iy1 = (int)(y1);
		iy2 = (int)(y2);

		for(y=iy1; y<=iy2; y++)
		{
			t = (y - iy1 + 0.5f) / (iy2 - iy1 + 1.0f);

			x = (int)(x1 + (x2 - x1) * t);
			c = LerpColor(c1, c2, t);

			m_DIB.PutPixel(x, y, c);
		}
	}
}


unsigned long LerpColor(unsigned long c1, unsigned long c2, float t)
{
	int r, g, b, a;
	a = (int)(_UNPACK_A(c1) + (_UNPACK_A(c2) - _UNPACK_A(c1)) * t);
	r = (int)(_UNPACK_R(c1) + (_UNPACK_R(c2) - _UNPACK_R(c1)) * t);
	g = (int)(_UNPACK_G(c1) + (_UNPACK_G(c2) - _UNPACK_G(c1)) * t);
	b = (int)(_UNPACK_B(c1) + (_UNPACK_B(c2) - _UNPACK_B(c1)) * t);
	return _PACK(r, g, b, a);
}
